import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { RestApiService } from '../rest-api.service';
import { ActivatedRoute, Router  } from '@angular/router';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators, FormArray } from '@angular/forms';
import { Location } from '@angular/common';


@Component({
  selector: 'app-create',
  templateUrl: './create.page.html',
  styleUrls: ['./create.page.scss'],
})
export class CreatePage implements OnInit {
  // classroomForm: FormGroup;
  // students: FormArray;
  projectForm: FormGroup;
  projects: FormGroup;
  constructor(private location: Location, public api: RestApiService,
              public loadingController: LoadingController,
              private route: ActivatedRoute,
              public router: Router,
              private formBuilder: FormBuilder) {
    // this.getClassroom(this.route.snapshot.paramMap.get('id'));
    // this.classroomForm = this.formBuilder.group({
    //   class_name : [null, Validators.required],
    //   students : this.formBuilder.array([])
    // });
    // this.getPorject(this.route.snapshot.paramMap.get('id'));
 
               }
// async getPorject(id) {
//   const loading = await this.loadingController.create({
//     message: 'Loading'
//   });
//   await loading.present();
//   await this.api.getProjectById(id).subscribe(res => {
//     this.classroomForm.controls.class_name.setValue(res.class_name);
//     const controlArray = this.classroomForm.controls.students as FormArray;
//     res.students.forEach(std => {
//       controlArray.push(this.formBuilder.group({
//          student_name: ''
//       }));
//     });
//     for (let i = 0; i < res.students.length; i++) {
//       controlArray.controls[i].get('student_name').setValue(res.students[i].student_name);
//     }
//     console.log(this.classroomForm);
//     loading.dismiss();
//   }, err => {
//     console.log(err);
//     loading.dismiss();
//   });
// }
async getProjects() {
  const loading = await this.loadingController.create({
    message: 'Loading'
  });
  await loading.present();
  await this.api.getProject()
    .subscribe(res => {
      console.log(res);
      this.projects = res;
      loading.dismiss();
    }, err => {
      console.log(err);
      loading.dismiss();
    });
}
// async getClassroom(id) {
//   const loading = await this.loadingController.create({
//     message: 'Loading'
//   });
//   await loading.present();
//   await this.api.getClassroomById(id).subscribe(res => {
//     this.classroomForm.controls.class_name.setValue(res.class_name);
//     const controlArray = this.classroomForm.controls.students as FormArray;
//     res.students.forEach(std => {
//       controlArray.push(this.formBuilder.group({
//          student_name: ''
//       }));
//     });
//     for (let i = 0; i < res.students.length; i++) {
//       controlArray.controls[i].get('student_name').setValue(res.students[i].student_name);
//     }
//     console.log(this.classroomForm);
//     loading.dismiss();
//   }, err => {
//     console.log(err);
//     loading.dismiss();
//   });
// }
// createStudent(): FormGroup {
//   return this.formBuilder.group({
//     student_name: ''
//   });
// }

// addBlankStudent(): void {
//   this.students = this.classroomForm.get('students') as FormArray;
//   this.students.push(this.createStudent());
// }
// deleteStudent(control, index) {
//   control.removeAt(index);
// }

async saveProject() {
  // console.log(' save projectForm : ', this.projectForm.value);
  await this.api.postProject(this.projectForm.value)
  .subscribe(res => {
    const id = res.id;
    console.log(' save projectForm : ', this.projectForm.value);
    // this.router.navigate(['/detail/' + id]);
    }, (err) => {
      console.log(err);
    });
}

// async saveClassroom() {
//   await this.api.postClassroom(this.classroomForm.value)
//   .subscribe(res => {
//     // this.location.back();
//       // const id = res.id;
//     // this.router.navigate(['/list']);
//     }, (err) => {
//       console.log(err);
//     });
// }
async onFormSubmit(form: NgForm) {
  const loading = await this.loadingController.create({
    message: 'Loading...'
  });
  await loading.present();
  await this.api.postProject(form)
    .subscribe(res => {
        let id = res._id;
        loading.dismiss();
        console.log(this.router);
        this.router.navigate([ '/detail/' + id ], { relativeTo: this.route.parent });
      }, (err) => {
        console.log(err);
        loading.dismiss();
      });
}
  ngOnInit() {
    this.projectForm = this.formBuilder.group({
      clientName : [null, Validators.required],
      wbsCode : [null, Validators.required],
      dataClassification : [null, Validators.required],
      los : [null, Validators.required],
      startDate : [null, Validators.required],
      endDate : [null, Validators.required],
      projectNumber : [null, Validators.required],
      projectMembers : [null, Validators.required]
    });
  }

}
