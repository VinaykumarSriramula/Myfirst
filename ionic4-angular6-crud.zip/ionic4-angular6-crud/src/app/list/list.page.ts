import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { RestApiService } from '../rest-api.service';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage implements OnInit {
  classrooms: any;
  projects: any;

  public items: Array<{ title: string; note: string; icon: string }> = [];
  constructor(public api: RestApiService, public loadingController: LoadingController) { }
  async getProjects() {
    const loading = await this.loadingController.create({
      message: 'Loading'
    });
    await loading.present();
    await this.api.getProject()
      .subscribe(res => {
        console.log(res);
        this.projects = res;
        loading.dismiss();
      }, err => {
        console.log(err);
        loading.dismiss();
      });
  }
    async getClassrooms() {
      const loading = await this.loadingController.create({
        message: 'Loading'
      });
      await loading.present();
      await this.api.getClassroom()
        .subscribe(res => {
          console.log(res);
          this.classrooms = res;
          loading.dismiss();
        }, err => {
          console.log(err);
          loading.dismiss();
        });
    }

  ngOnInit() {
    // this.getClassrooms();
    this.getProjects();
  }
  // add back when alpha.4 is out
  // navigate(item) {
  //   this.router.navigate(['/list', JSON.stringify(item)]);
  // }
}
