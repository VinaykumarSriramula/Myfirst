import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import { RepositoryService } from 'src/app/shared/repository.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-project-update',
  templateUrl: './project-update.component.html',
  styleUrls: ['./project-update.component.css']
})
export class ProjectUpdateComponent implements OnInit {
  public projectForm1: FormGroup;
  id = '';
  clientName = '';
  wbsCode = '';
  dataClassification = '';
  los = '';
  startDate = '';
  endDate = '';
  projectNumber = '';
  projectMembers = '';

  constructor(private location: Location, private route: ActivatedRoute, private repository: RepositoryService) { }

  ngOnInit() {
    this.projectForm1 = new FormGroup({
      clientName: new FormControl('', Validators.required),
      wbsCode: new FormControl('', Validators.required),
      dataClassification: new FormControl('', Validators.required),
      los: new FormControl('', Validators.required),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      projectNumber: new FormControl('', Validators.required),
      projectMembers: new FormControl('', Validators.required)
    });
    console.log('from url' , this.route.snapshot.params['_id']);
    this.id = this.route.snapshot.params['_id'];
    this.clientName = this.route.snapshot.params['clientName'];
    this.wbsCode = this.route.snapshot.params['wbsCode'];
    this.dataClassification = this.route.snapshot.params['dataClassification'];
    this.los = this.route.snapshot.params['los'];
    this.startDate = this.route.snapshot.params['startDate'];
    this.endDate = this.route.snapshot.params['endDate'];
    this.projectNumber = this.route.snapshot.params['projectNumber'];
    this.projectMembers = this.route.snapshot.params['projectMembers'];
  }

  public onCancel = () => {
    this.location.back();
  }
  public updateProject = (projectFormValue) => {
      this.executeProjectUpdatetion(projectFormValue);
  }
  private executeProjectUpdatetion = (projectFormValue) => {

    const apiUrl = `${this.id}`;
    this.repository.update(apiUrl, projectFormValue)
      .subscribe(res => {
        this.location.back();
      },
      (error => {
        this.location.back();
      })
    );
  }

}
