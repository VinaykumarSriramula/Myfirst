import { Component, OnInit } from '@angular/core';
import { RepositoryService } from '../../shared/repository.service';
import { Project } from '../../Model/Project';
import { MatTableDataSource} from '@angular/material';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {
  public displayedColumns = ['clientName', 'wbsCode', 'dataClassification', 'los', 'startDate', 'endDate',
                             'projectNumber', 'projectMembers', 'update', 'delete'];
  // public displayedColumns = ['clientName', 'wbsCode', 'dataClassification', 'los', 'startDate', 'endDate',
  //                           'projectNumber', 'projectMembers', 'Edit', 'delete'];
  public dataSource = new MatTableDataSource<Project>();
  constructor(private location: Location, private router: Router, private repoService: RepositoryService) { }

  ngOnInit() {
    this.getAllProjects();
  }
  public getAllProjects = () => {
    this.repoService.getData('')
    .subscribe(res => {
      this.dataSource.data = res as Project[];
    });
  }
  public redirectToDetails = (id: string) => {

  }

  public redirectToUpdatePage(id){
      let updateUrl: string = `/owner/update/${id}`;
      this.router.navigate([updateUrl]);
  }
  public redirectToUpdate = (row: any) => {
    this.router.navigate(['/update', row._id, row.clientName, row.wbsCode, row.dataClassification,
    row.los, row.startDate, row.endDate, row.projectNumber, row.projectMembers]);
    console.log('my row', row._id);
  }

  public redirectToDelete = (row: any) => {
    console.log( 'inside redi delete :', row);
    const apiUrl = `${row._id}`;
    this.repoService.delete(apiUrl)
      .subscribe(res => {

      },
      (error => {
        this.location.back();
      })
    );
  }
}
