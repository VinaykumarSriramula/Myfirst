import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import { RepositoryService } from 'src/app/shared/repository.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-project-delete',
  templateUrl: './project-delete.component.html',
  styleUrls: ['./project-delete.component.css']
})
export class ProjectDeleteComponent implements OnInit {
  id = '';
  constructor(private location: Location, private route: ActivatedRoute, private repository: RepositoryService) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['_id'];
  }

}
