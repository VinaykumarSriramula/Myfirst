import { Component, OnInit } from '@angular/core';
import { RepositoryService } from '../../shared/repository.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { ProjectforCreation} from '../../Model/ProjectforCreation';

@Component({
  selector: 'app-project-create',
  templateUrl: './project-create.component.html',
  styleUrls: ['./project-create.component.css']
})
export class ProjectCreateComponent implements OnInit {
  public projectForm: FormGroup;

  constructor(private location: Location, private repository: RepositoryService) { }


  ngOnInit() {
    this.projectForm = new FormGroup({
      clientName: new FormControl('', Validators.required),
      wbsCode: new FormControl('', Validators.required),
      dataClassification: new FormControl('', Validators.required),
      los: new FormControl('', Validators.required),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      projectNumber: new FormControl('', Validators.required),
      projectMembers: new FormControl('', Validators.required)
    });
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.projectForm.controls[controlName].hasError(errorName);
  }

  public onCancel = () => {
    this.location.back();
  }

  public createProject = (projectFormValue) => {
    if (this.projectForm.valid) {
      this.executeProjectCreation(projectFormValue);
    }
  }
  private executeProjectCreation = (projectFormValue) => {
    const project: ProjectforCreation = {
      clientName: projectFormValue.clientName,
      wbsCode: projectFormValue.wbsCode,
      dataClassification: projectFormValue.dataClassification,
      los: projectFormValue.los,
      startDate: projectFormValue.startDate,
      endDate: projectFormValue.endDate,
      projectNumber: projectFormValue.projectNumber,
      projectMembers: projectFormValue.projectMembers,

    }

    const apiUrl = '';
    this.repository.create(apiUrl, project)
      .subscribe(res => {
        //this is temporary, until we create our dialogs
        this.location.back();
      },
      (error => {
        //temporary as well
        this.location.back();
      })
    );
  }

}
