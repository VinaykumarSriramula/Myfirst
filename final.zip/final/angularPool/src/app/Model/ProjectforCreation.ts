export interface ProjectforCreation {
  clientName: string;
  wbsCode: string;
  dataClassification: string;
  los: string;
  startDate: string;
  endDate: string;
  projectNumber: string;
  projectMembers: string;
}
