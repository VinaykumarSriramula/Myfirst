import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ProjectListComponent } from '../app/project/project-list/project-list.component';
import { Routes, RouterModule } from '@angular/router';
import { MatTableModule, MatPaginatorModule, MatFormFieldModule,
         MatInputModule, MatSortModule, MatMenuModule, MatListModule,
         MatIconModule, MatButtonModule, MatCardModule, MatToolbarModule, MatSidenavModule, MatTabsModule } from '@angular/material';
import { CommonModule } from '@angular/common';
import { ProjectCreateComponent } from '../app/project/project-create/project-create.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ProjectUpdateComponent } from './project/project-update/project-update.component';
import { ProjectDeleteComponent } from './project/project-delete/project-delete.component';

const routes: Routes = [
  {
    path: 'list',
    component: ProjectListComponent
  },
  {
    path: 'create',
     component: ProjectCreateComponent
  },
  { path: 'update/:_id/:clientName/:wbsCode/:dataClassification/:los/:startDate/:endDate/:projectNumber/:projectMembers',
   component: ProjectUpdateComponent
  },
  {
  path: 'delete/:_id',
   component: ProjectDeleteComponent
  }

];

@NgModule({
  declarations: [
    AppComponent,
    ProjectListComponent,
    ProjectCreateComponent,
    ProjectUpdateComponent,
    ProjectDeleteComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSortModule,
    MatTableModule,
    MatMenuModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    CommonModule,
    MatTabsModule,
    MatSidenavModule,
    MatCardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
