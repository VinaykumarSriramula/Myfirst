import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const urlAddress = 'http://localhost:3200/projects/';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {

  constructor(private http: HttpClient) { }

  public getData = (route: string) => {
    return this.http.get(urlAddress + `list`);
  }

  public create = (route: string, body) => {
    return this.http.post(urlAddress + `addProject`, body, this.generateHeaders());
  }

  public update = (route: string, body) => {
    return this.http.put(urlAddress + `updateProject/${route}`, body, this.generateHeaders());
  }

  public delete = (route: string) => {
    return this.http.delete(urlAddress + `deleteProject/${route}`);
  }

  private createCompleteRoute = (route: string, envAddress: string) => {
    return `${envAddress}/${route}`;
  }

  private generateHeaders = () => {
    return {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
  }
}
