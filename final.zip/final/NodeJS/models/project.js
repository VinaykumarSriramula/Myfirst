const mongoose = require('mongoose');

var Project = mongoose.model('Project', {
    clientName: { type: String, required: true },
    wbsCode: { type: String, required: true },
    dataClassification: { type: String, required: true },
    los: { type: String, required: true },
    startDate: { type: String, required: true },
    endDate: { type: String, required: true },
    projectNumber: { type: String, required: true },
    projectMembers: { type: String, required: true }

});

module.exports = { Project };

