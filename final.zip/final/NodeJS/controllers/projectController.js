const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { Project } = require('../models/project');

// => localhost:3000/projects/
router.get('/list', (req, res) => {
    Project.find((err, docs) => {
        if (!err) { res.send(docs);
            console.log('inside projects :'+docs); }
       
        else { console.log('Error in Retriving Project :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.get('/editProject/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

        Project.findById(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Retriving Project :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.post('/addProject', (req, res) => {
    var pro = new Project({

        clientName: req.body.clientName,
        wbsCode: req.body.wbsCode,
        dataClassification: req.body.dataClassification,
        los: req.body.los,
        startDate: req.body.startDate,
        endDate: req.body.endDate,
        projectNumber: req.body.projectNumber,
        projectMembers: req.body.projectMembers
    });
    pro.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Project Save :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.put('/updateProject/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var pro = {
        clientName: req.body.clientName,
        wbsCode: req.body.wbsCode,
        dataClassification: req.body.dataClassification,
        los: req.body.los,
        startDate: req.body.startDate,
        endDate: req.body.endDate,
        projectNumber: req.body.projectNumber,
        projectMembers: req.body.projectMembers,
    };
    Project.findByIdAndUpdate(req.params.id, { $set: pro }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Project Update :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.delete('/deleteProject/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

        Project.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Project Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports = router;