const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const { mongoose } = require('./db.js');
var projectController = require('./controllers/projectController.js');

var app = express();
app.use(bodyParser.json());
app.use(cors());

var port = 3200;

app.listen(port, () => console.log('Server started at port : ' +port));


app.use('/projects', projectController);